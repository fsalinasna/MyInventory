﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using searchupclient.UPCSearch;
namespace searchupclient
{
    class Program
    {
        static void Main(string[] args)
        {
            string accessToken = "PLACE_YOUR_ACCESS_TOKEN_HERE";
            string upc = "9781585678815";
            UPCSearchSoapClient upcclient = new UPCSearchSoapClient();
            Console.WriteLine("Products matched for UPC Code: " + upc + " in CSV Format");
            Console.WriteLine("=========================================================");
            Console.WriteLine("");
            Console.WriteLine(upcclient.GetProduct(upc, accessToken));
            Console.ReadLine();
        }
    }
}
